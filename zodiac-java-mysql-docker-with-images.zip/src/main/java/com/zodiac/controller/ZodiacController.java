
package com.zodiac.controller;

import com.zodiac.service.ZodiacService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
public class ZodiacController {

    private final ZodiacService zodiacService;

    public ZodiacController(ZodiacService zodiacService) {
        this.zodiacService = zodiacService;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/zodiac")
    public String zodiac(@RequestParam String name,
                         @RequestParam String birthdate,
                         Model model) {

        try {
            LocalDate date = LocalDate.parse(birthdate);
            String sign = zodiacService.saveSubmission(name, date);

            model.addAttribute("name", name);
            model.addAttribute("birthdate", birthdate);
            model.addAttribute("sign", sign);
            model.addAttribute("image", "/images/" + sign + ".jpg");
            model.addAttribute("total", zodiacService.totalSubmissions());

        } catch (Exception e) {
            model.addAttribute("error", "Please enter a valid name and birth date.");
        }

        return "index";
    }

    @GetMapping("/stats")
    @ResponseBody
    public String stats() {
        return "Total users: " + zodiacService.totalSubmissions();
    }
}
