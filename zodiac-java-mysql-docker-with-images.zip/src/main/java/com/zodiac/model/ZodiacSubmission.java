package com.zodiac.model;

import jakarta.persistence.*;

import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "users")
public class ZodiacSubmission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "birth_date", nullable = false)
    private LocalDate birthDate;

    @Column(name = "zodiac_sign", nullable = false, length = 50)
    private String zodiacSign;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    public ZodiacSubmission() {
    }

    public ZodiacSubmission(String name, LocalDate birthDate, String zodiacSign) {
        this.name = name;
        this.birthDate = birthDate;
        this.zodiacSign = zodiacSign;
    }

    @PrePersist
    public void prePersist() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getZodiacSign() {
        return zodiacSign;
    }

    public void setZodiacSign(String zodiacSign) {
        this.zodiacSign = zodiacSign;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
