package com.zodiac.repository;

import com.zodiac.model.ZodiacSubmission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ZodiacSubmissionRepository extends JpaRepository<ZodiacSubmission, Long> {
}
