
package com.zodiac.service;

import com.zodiac.model.ZodiacSubmission;
import com.zodiac.repository.ZodiacSubmissionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class ZodiacService {

    private final ZodiacSubmissionRepository repository;

    public ZodiacService(ZodiacSubmissionRepository repository) {
        this.repository = repository;
    }

    public String calculateZodiacSign(LocalDate birthDate) {
        int month = birthDate.getMonthValue();
        int day = birthDate.getDayOfMonth();

        if ((month == 3 && day >= 21) || (month == 4 && day <= 19))
            return "aries";

        if ((month == 4 && day >= 20) || (month == 5 && day <= 20))
            return "taurus";

        if ((month == 5 && day >= 21) || (month == 6 && day <= 20))
            return "gemini";

        if ((month == 6 && day >= 21) || (month == 7 && day <= 22))
            return "cancer";

        if ((month == 7 && day >= 23) || (month == 8 && day <= 22))
            return "leo";

        if ((month == 8 && day >= 23) || (month == 9 && day <= 22))
            return "virgo";

        if ((month == 9 && day >= 23) || (month == 10 && day <= 22))
            return "libra";

        if ((month == 10 && day >= 23) || (month == 11 && day <= 21))
            return "scorpio";

        if ((month == 11 && day >= 22) || (month == 12 && day <= 21))
            return "sagittarius";

        if ((month == 12 && day >= 22) || (month == 1 && day <= 19))
            return "capricorn";

        if ((month == 1 && day >= 20) || (month == 2 && day <= 18))
            return "aquarius";

        return "pisces";
    }

    /**
     * Saves the user's name + birth date + calculated zodiac sign to the SQL database.
     */
    public String saveSubmission(String name, LocalDate birthDate) {
        String sign = calculateZodiacSign(birthDate);
        repository.save(new ZodiacSubmission(name.trim(), birthDate, sign));
        return sign;
    }

    public long totalSubmissions() {
        return repository.count();
    }
}
